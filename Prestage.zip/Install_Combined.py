# $language = "Python"
# $interface = "1.0"

# =============================================================================
# Combined Script: Prechecks → Install Mode Upgrade → Postchecks
# Runs all three phases sequentially without any manual prompts.
# Connection-loss protected: every screen read is wrapped in try/except so a
# dropped session raises a clean error instead of crashing with ScriptError.
# =============================================================================

import os
import re
import time

# ----------------------------
# User-editable constants
# ----------------------------
EXPECTED_MD5      = "093073af42fd6646da0dac0e98d68fc7"
IMAGE_BIN         = "cat9k_iosxe.17.15.06.SPA.bin"
IMAGE_CONF        = "cat9k_iosxe.17.15.06.SPA.conf"
FTP_URL           = "ftp://10.233.30.222/cat9k/" + IMAGE_BIN

ECHO_SUPPRESS_SEC = 1.0

PRECHECK_LOGDIR   = r"C:\Logs\Prechecks"
POSTCHECK_LOGDIR  = r"C:\Logs\postcheck"
IMPLEMENT_LOGDIR  = r"C:\Logs\Implement"

CHECK_COMMANDS = [
    "show clock",
    "show version",
    "show ip interface brief",
    "show interfaces status",
    "show interfaces trunk",
    "show module",
    "show vlan brief",
    "show post",
    "show boot",
    "show power inline",
    "show spanning-tree detail",
    "dir",
    "show mac address-table",
    "show flash:",
    "show ip arp",
    "show switch",
    "show env all",
]

# ----------------------------
# Phase 4 — Post-upgrade validation targets
# ----------------------------
EXPECTED_BOOT_LINES = [
    "Boot Variables on next reload:",
    "BOOT variable = flash:packages.conf;",
]

EXPECTED_BUILD_LINES = [
    "# pkginfo: Build: 17.15.06",
]

EXPECTED_PACKAGES = [
    "cat9k-rpboot.17.15.06.SPA.pkg",
    "cat9k-wlc.17.15.06.SPA.pkg",
    "cat9k-webui.17.15.06.SPA.pkg",
    "cat9k-srdriver.17.15.06.SPA.pkg",
    "cat9k-rpbase.17.15.06.SPA.pkg",
    "cat9k-lni.17.15.06.SPA.pkg",
    "cat9k-guestshell.17.15.06.SPA.pkg",
    "cat9k-cc_srdriver.17.15.06.SPA.pkg",
]

REPORT_LOGDIR       = r"C:\Logs\Report"
REPORT_SUMMARY_FILE = os.path.join(REPORT_LOGDIR, "Upgrade_Validation_Report.csv")
REPORT_SUMMARY_HTML = os.path.join(REPORT_LOGDIR, "Upgrade_Validation_Report.html")

REPORT_CSS = """
    body { font-family: "Segoe UI", Arial, sans-serif; background:#f4f6f8; color:#1f2937; margin:0; padding:24px; }
    h1 { font-size:20px; margin:0 0 4px 0; }
    .meta { color:#6b7280; font-size:13px; margin-bottom:20px; }
    table { border-collapse:collapse; width:100%; background:#ffffff; box-shadow:0 1px 3px rgba(0,0,0,0.12); }
    th, td { padding:10px 14px; text-align:left; border-bottom:1px solid #e5e7eb; font-size:14px; vertical-align:top; }
    th { background:#111827; color:#ffffff; text-transform:uppercase; font-size:12px; letter-spacing:0.03em; }
    tr:last-child td { border-bottom:none; }
    tr:hover td { background:#f9fafb; }
    .pill { font-weight:600; padding:3px 10px; border-radius:12px; display:inline-block; font-size:12px; }
    .pill-pass { color:#065f46; background:#d1fae5; }
    .pill-fail { color:#991b1b; background:#fee2e2; }
    .banner { padding:14px 18px; border-radius:6px; font-size:16px; font-weight:600; margin-bottom:20px; border:1px solid; }
    .banner-success { background:#d1fae5; color:#065f46; border-color:#6ee7b7; }
    .banner-notdone { background:#fee2e2; color:#991b1b; border-color:#fca5a5; }
    .pill-error { color:#92400e; background:#fef3c7; }
    code { background:#f3f4f6; padding:2px 6px; border-radius:4px; font-size:13px; }
    pre { background:#0f172a; color:#e2e8f0; padding:12px; border-radius:6px; font-size:12px; overflow-x:auto; white-space:pre-wrap; margin:6px 0 0 0; }
    .missing { color:#991b1b; font-size:12px; margin-top:4px; }
    .controls { display:flex; align-items:center; gap:12px; margin-bottom:16px; flex-wrap:wrap; }
    .search-box { padding:8px 12px; border:1px solid #d1d5db; border-radius:6px; font-size:14px; width:260px; }
    .search-box:focus { outline:none; border-color:#111827; }
    .stat { background:#ffffff; border:1px solid #e5e7eb; border-radius:6px; padding:6px 14px; font-size:13px; color:#374151; }
    .stat b { font-size:15px; color:#111827; }
    .tabs { display:flex; gap:6px; margin-bottom:16px; flex-wrap:wrap; }
    .tab-btn { padding:6px 14px; border-radius:6px; border:1px solid #d1d5db; background:#ffffff; cursor:pointer; font-size:13px; color:#374151; }
    .tab-btn.active { background:#111827; color:#ffffff; border-color:#111827; }
    tr.hidden-row { display:none; }
    .no-results { text-align:center; color:#6b7280; padding:24px; display:none; }
"""

SEARCH_JS = """
function filterDevices() {
    var q = document.getElementById('deviceSearch').value.trim().toLowerCase();
    var activeBtn = document.querySelector('.tab-btn.active');
    var activeStatus = activeBtn ? activeBtn.getAttribute('data-status') : 'ALL';
    var rows = document.querySelectorAll('#deviceTable tbody tr[data-hostname]');
    var visible = 0;
    rows.forEach(function(row) {
        var host = row.getAttribute('data-hostname');
        var status = row.getAttribute('data-status');
        var matchesSearch = !q || host.indexOf(q) !== -1;
        var matchesStatus = activeStatus === 'ALL' || status === activeStatus;
        if (matchesSearch && matchesStatus) {
            row.classList.remove('hidden-row');
            visible++;
        } else {
            row.classList.add('hidden-row');
        }
    });
    var vc = document.getElementById('visibleCount');
    if (vc) { vc.textContent = visible; }
    var nr = document.querySelector('.no-results');
    if (nr) { nr.style.display = visible === 0 ? 'block' : 'none'; }
}
function setDeviceTab(btn) {
    document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');
    filterDevices();
}
"""


def _html_escape(text):
    return (str(text).replace("&", "&amp;")
                      .replace("<", "&lt;")
                      .replace(">", "&gt;"))


# =============================================================================
# Connection guard
# =============================================================================

def _check_connected(tab):
    """Raise a clean exception if the session has dropped."""
    if not tab.Session.Connected:
        raise Exception("Connection lost — session is no longer connected.")


# =============================================================================
# Shared helpers
# =============================================================================

def _detect_hostname_and_prompt():
    try:
        crt.Screen.Send("\r")
        time.sleep(0.2)
        crt.Screen.Send("term len 0\r")
        time.sleep(0.3)
        crt.Screen.Send("show version | include uptime\r")
        time.sleep(0.5)
        row  = crt.Screen.CurrentRow
        col  = crt.Screen.CurrentColumn
        text = crt.Screen.Get(max(1, row - 20), 1, row, col)
        hostname = None
        for line in text.splitlines():
            m = re.search(r"^(\S+)\s+uptime is", line.strip())
            if m:
                hostname = m.group(1)
                break
        if not hostname:
            crt.Screen.Send("\r")
            time.sleep(0.2)
            line = crt.Screen.Get(
                crt.Screen.CurrentRow, 1,
                crt.Screen.CurrentRow, crt.Screen.CurrentColumn
            ).strip()
            m = re.match(r"^(\S+)[>#]$", line)
            if m:
                hostname = m.group(1)
        if not hostname:
            hostname = "UNKNOWN"
        return hostname, hostname + "#"
    except Exception as e:
        raise Exception("Failed to detect hostname: {}".format(e))


def _get_prompt_from_screen(screen):
    try:
        screen.Send("\r")
        time.sleep(1)
        row = screen.CurrentRow
        return screen.Get(row, 1, row, screen.CurrentColumn).strip()
    except Exception:
        return ""


def _sanitise_hostname(raw):
    for ch in ("/", "\\", ":", " "):
        raw = raw.replace(ch, "_")
    return raw


def _ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def _clean_output(raw, cmd, prompt):
    """Strip ANSI escapes, control chars, echoed command, and bare prompt lines."""
    ansi_escape = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')
    raw = ansi_escape.sub('', raw)
    raw = raw.replace('\r', '').replace('\x08', '').replace('\x07', '')

    cleaned = []
    for line in raw.splitlines():
        s = line.rstrip()
        if s.strip() == cmd.strip():
            continue
        if re.match(r'^\S+[>#]\s*$', s.strip()):
            continue
        prompt_bare = prompt.rstrip()
        if s.strip().startswith(prompt_bare):
            if not s.strip()[len(prompt_bare):].strip():
                continue
        cleaned.append(s)

    while cleaned and not cleaned[0].strip():
        cleaned.pop(0)
    while cleaned and not cleaned[-1].strip():
        cleaned.pop()

    return '\n'.join(cleaned)


# =============================================================================
# Install Mode screen helpers — all wrapped for connection safety
# =============================================================================

def _wait_for_prompt(prompt, timeout=120):
    try:
        crt.Screen.WaitForString(prompt, timeout)
    except Exception as e:
        raise Exception("Connection lost while waiting for prompt: {}".format(e))


def _send_and_wait(cmd, prompt, timeout=120, pre_delay=0.1):
    try:
        crt.Screen.Send(cmd + "\r")
        if pre_delay:
            time.sleep(pre_delay)
        _wait_for_prompt(prompt, timeout)
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _send_long_and_wait(cmd, prompt, timeout=3600):
    try:
        crt.Screen.Send(cmd + "\r")
        _wait_for_prompt(prompt, timeout)
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _read_cmd_output(cmd, prompt, timeout=3600):
    """Send cmd and read until the real prompt reappears, advancing past
    any pager ('--More--') along the way.

    Uses the single-argument WaitForString(prompt, timeout) in a short
    polling loop rather than a multi-string ReadString() call — this
    environment's IronPython/.NET binding has thrown inconsistent
    overload-resolution errors ('takes at most 3 positional arguments',
    'an integer is required') on multi-arg ReadString() calls, so this
    sticks to the one call shape that's reliably well-defined."""
    POLL_SECONDS = 2
    try:
        start_row = crt.Screen.CurrentRow
        crt.Screen.Send(cmd + "\r")
        deadline = time.time() + timeout
        matched = False
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                raise Exception("Timed out after {}s waiting for prompt".format(timeout))
            poll = min(POLL_SECONDS, max(1, int(remaining)))
            matched = crt.Screen.WaitForString(prompt, poll)
            if matched:
                break
            row = crt.Screen.CurrentRow
            col = crt.Screen.CurrentColumn
            visible = crt.Screen.Get(max(1, row - 3), 1, row, col)
            if re.search(r'-+\s*More\s*-+', visible):
                crt.Screen.Send(" ")
        row = crt.Screen.CurrentRow
        col = crt.Screen.CurrentColumn
        # Capture only from where this command was sent onward, not the
        # whole screen buffer, so earlier commands' output can't leak in.
        return crt.Screen.Get(start_row, 1, row, col)
    except Exception as e:
        raise Exception("Connection lost reading output of '{}': {}".format(cmd, e))


def _send_with_confirm(cmd, prompt, timeout=600):
    try:
        crt.Screen.Send(cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["[confirm]", "Destination filename", "dest filename", "overwrite", prompt],
                timeout
            )
            if idx in [1, 2, 3, 4]:
                crt.Screen.Send("\r")
            elif idx == 5:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _copy_with_enter_when_prompted(copy_cmd, prompt, timeout=7200):
    try:
        crt.Screen.Send(copy_cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["Destination filename", "Address or name of remote host", "Password:", prompt],
                timeout
            )
            if idx in [1, 2, 3]:
                crt.Screen.Send("\r")
            elif idx == 4:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during copy: {}".format(e))


def _copy_running_to_flash(dest_filename, prompt, timeout=900):
    try:
        crt.Screen.Send("copy running-config flash:{}\r".format(dest_filename))
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["Destination filename", "[confirm]", "copied", prompt],
                timeout
            )
            if idx in [1, 2]:
                crt.Screen.Send("\r")
            elif idx == 4:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during config backup: {}".format(e))


def _expand_package(cmd, prompt, timeout=7200, echo_suppress=ECHO_SUPPRESS_SEC):
    """Send 'request platform software package expand ... verbose' and wait
    for it to genuinely finish before returning.

    Why this exists: with a plain WaitForString(prompt), the router prompt
    text can appear to match too early — either as part of the command's own
    echo, or because verbose expand output momentarily reprints prompt-like
    text mid-run. That caused the *next* command (rename flash:packages.conf)
    to be sent while expansion was still in progress, i.e. command overlap.

    Fix: (1) ignore any prompt match seen within echo_suppress seconds of
    sending, same as the other confirm/copy helpers in this script, and
    (2) explicitly look for the command's own SUCCESS/FAILED completion
    marker before accepting the prompt as real completion.
    """
    try:
        crt.Screen.Send(cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["SUCCESS: Finished expanding", "FAILED:", prompt],
                timeout
            )
            if idx in (1, 2):
                # Explicit completion marker seen — settle back to the prompt.
                crt.Screen.WaitForString(prompt, 120)
                break
            elif idx == 3:
                if time.time() - start < echo_suppress:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _send_yes_if_prompted(cmd, prompt, timeout=3600):
    try:
        crt.Screen.Send(cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["[y/n]", "(y/n)", "[confirm]", prompt],
                timeout
            )
            if idx in [1, 2]:
                crt.Screen.Send("y\r")
            elif idx == 3:
                crt.Screen.Send("\r")
            elif idx == 4:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


# =============================================================================
# Phase 1 — Prechecks
# =============================================================================

def run_prechecks(screen, hostname, prompt, logdir):
    _ensure_dir(logdir)
    logfile = os.path.join(logdir, "{}.log".format(hostname))

    crt.Session.SetStatusText("[PRECHECK] Disabling paging...")
    try:
        screen.Send("terminal length 0\r")
        screen.WaitForString(prompt, 30)
    except Exception as e:
        raise Exception("Connection lost at start of prechecks: {}".format(e))

    with open(logfile, "w") as f:
        f.write("Hostname : {}\n".format(hostname))
        f.write("Collected: {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
        f.write("\n")

        for cmd in CHECK_COMMANDS:
            crt.Session.SetStatusText("[PRECHECK] Running: {}".format(cmd))
            try:
                screen.Send(cmd + "\r")
                screen.WaitForString(cmd, 10)
                raw = screen.ReadString(prompt, 300)
            except Exception as e:
                f.write("=" * 70 + "\n")
                f.write("COMMAND : {}\n".format(cmd))
                f.write("=" * 70 + "\n")
                f.write("ERROR   : {}\n\n".format(str(e)))
                # If it looks like a connection loss, stop collecting
                if "connect" in str(e).lower() or "lost" in str(e).lower():
                    f.write("(Stopping precheck collection — connection lost)\n")
                    break
                continue

            output = _clean_output(raw, cmd, prompt)
            f.write("=" * 70 + "\n")
            f.write("COMMAND : {}\n".format(cmd))
            f.write("=" * 70 + "\n")
            f.write(output + "\n" if output else "(no output)\n")
            f.write("\n")
            time.sleep(0.5)

    crt.Session.SetStatusText("[PRECHECK] Complete — {}".format(logfile))


# =============================================================================
# Phase 2 — Install Mode Upgrade
# =============================================================================

def _start_implement_logging(hostname):
    """Create C:\\Logs\\Implement (if needed) and start SecureCRT session
    logging, right before Phase 2 — Install Mode begins.
    Filename: <hostname>_Install.log"""
    _ensure_dir(IMPLEMENT_LOGDIR)
    logfile = os.path.join(
        IMPLEMENT_LOGDIR,
        "{}_Install.log".format(hostname)
    )
    crt.Session.LogFileName = logfile
    crt.Session.Log(True)
    return logfile


def _stop_implement_logging():
    """Stop SecureCRT session logging. Safe to call even if logging was
    never started or the session has already dropped."""
    try:
        crt.Session.Log(False)
    except Exception:
        pass


def run_install_mode(prompt):
    # Backup config
    crt.Session.SetStatusText("[INSTALL] Backing up running config...")
    _copy_running_to_flash("config_{}".format(time.strftime("%d_%m_%Y")), prompt)

    # Basic checks
    for cmd in ("term len 0", "show version", "show clock",
                "show platform", "show inventory", "dir flash:"):
        crt.Session.SetStatusText("[INSTALL] {}".format(cmd))
        _send_and_wait(cmd, prompt)

    # Ping check
    crt.Session.SetStatusText("[INSTALL] Ping check to FTP server...")
    ping_out = _read_cmd_output("ping 10.233.30.222", prompt, timeout=120)
    if ("Success rate is 0 percent" in ping_out
            or "0/5" in ping_out
            or "Unreachable" in ping_out):
        crt.Dialog.MessageBox("Ping to FTP server FAILED. Stopping script.")
        raise Exception("Ping failed — aborting.")

    _send_and_wait("show install active", prompt)

    # Check if image already exists on flash BEFORE cleaning —
    # 'install remove inactive' purges inactive package files, which
    # would delete an already-downloaded image before we get to use it.
    crt.Session.SetStatusText("[INSTALL] Checking if image already exists on flash...")
    dir_check = _read_cmd_output("dir flash:{}".format(IMAGE_BIN), prompt, timeout=60)
    dir_check = _clean_output(dir_check, "dir flash:{}".format(IMAGE_BIN), prompt)

    image_present = ("%Error" not in dir_check
                      and "No such file" not in dir_check
                      and IMAGE_BIN in dir_check)

    if image_present:
        crt.Session.SetStatusText(
            "[INSTALL] {} already present on flash — skipping clean and copy.".format(IMAGE_BIN))
    else:
        # Clean flash
        crt.Session.SetStatusText("[INSTALL] Cleaning flash...")
        _send_yes_if_prompted("install remove inactive", prompt, timeout=3600)

        _send_and_wait("dir flash:*.bin", prompt)
        _send_and_wait("dir flash: | inc free", prompt)

        # Copy image
        crt.Session.SetStatusText("[INSTALL] Copying image from FTP (may take a while)...")
        _copy_with_enter_when_prompted("copy {} flash:".format(FTP_URL), prompt, timeout=7200)

    _send_and_wait("dir flash:*.bin", prompt)

    # Verify integrity
    crt.Session.SetStatusText("[INSTALL] Verifying image integrity...")
    _send_long_and_wait("verify flash:{}".format(IMAGE_BIN), prompt, timeout=3600)

    # MD5 check
    crt.Session.SetStatusText("[INSTALL] Verifying MD5 hash...")
    md5_out      = _read_cmd_output("verify /md5 flash:{}".format(IMAGE_BIN), prompt, timeout=3600)
    md5_match    = re.search(r"=\s*([A-Fa-f0-9]{32})", md5_out)
    computed_md5 = md5_match.group(1).lower() if md5_match else "NOT_FOUND"

    if computed_md5 != EXPECTED_MD5.lower():
        crt.Dialog.MessageBox(
            "MD5 MISMATCH!\nExpected: {}\nGot: {}\nStopping script.".format(
                EXPECTED_MD5, computed_md5))
        raise Exception("MD5 mismatch — aborting.")

    # Check whether packages.conf already exists on flash — done here,
    # right after MD5 verification and before expand, so the check sees
    # flash exactly as it was before expand adds any new package files.
    # The result (packages_conf_present) is used further down, after
    # expand, to decide whether to run the rename process at all.
    #
    # Two hardening points vs. the original version of this check:
    #  1. Filter server-side with '| include packages.conf' instead of
    #     grepping the full 'dir flash:' listing client-side — less output
    #     to misparse.
    #  2. Only count a line as a real hit if it looks like an actual `dir`
    #     listing row (starts with the numeric index column) AND its last
    #     whitespace-separated field — the filename — is packages.conf
    #     exactly, rather than a bare substring search that could match
    #     stray text elsewhere in the output.
    crt.Session.SetStatusText("[INSTALL] Checking flash for existing packages.conf...")
    dir_filter_cmd = "dir flash: | include packages.conf"
    flash_dir_check = _read_cmd_output(dir_filter_cmd, prompt, timeout=60)
    flash_dir_check = _clean_output(flash_dir_check, dir_filter_cmd, prompt)

    def _is_real_dir_hit(line, filename):
        parts = line.split()
        return (len(parts) >= 2
                and parts[0].isdigit()
                and parts[-1].strip().lower() == filename.lower())

    packages_conf_present = any(
        _is_real_dir_hit(line, "packages.conf") for line in flash_dir_check.splitlines()
    )

    crt.Session.SetStatusText(
        "[INSTALL] packages.conf check — raw: {!r} -> present={}".format(
            flash_dir_check.strip()[:200], packages_conf_present))

    # Expand image
    crt.Session.SetStatusText("[INSTALL] Expanding image package (may take a while)...")
    _expand_package(
        "request platform software package expand file flash:{} verbose".format(IMAGE_BIN),
        prompt, timeout=7200)

    # Rename configs — decision was made above (right after MD5 verify,
    # before expand added any new files to flash) based on whether
    # packages.conf already existed at that point.
    if packages_conf_present:
        crt.Session.SetStatusText("[INSTALL] Renaming existing packages.conf to backup...")
        _send_with_confirm("rename flash:packages.conf flash:packages_backup.conf", prompt)
        crt.Session.SetStatusText("[INSTALL] Renaming {} to packages.conf...".format(IMAGE_CONF))
        _send_with_confirm("rename flash:{} flash:packages.conf".format(IMAGE_CONF), prompt)
    else:
        crt.Session.SetStatusText(
            "[INSTALL] packages.conf not found on flash — skipping both renames.")

    # Final checks — skip 'more flash:packages.conf' when we know it isn't
    # there, since that guarantees a '%Error opening ...' on screen instead
    # of useful output.
    final_cmds = ["show boot system", "write memory"]
    if packages_conf_present:
        final_cmds.insert(0, "more flash:packages.conf")
    for cmd in final_cmds:
        crt.Session.SetStatusText("[INSTALL] {}".format(cmd))
        _send_and_wait(cmd, prompt)

    crt.Session.SetStatusText("[INSTALL] Install mode preparation complete.")


# =============================================================================
# Phase 3 — Postchecks
# =============================================================================

def run_postchecks(screen, hostname, prompt, logdir):
    _ensure_dir(logdir)
    logfile = os.path.join(logdir, "{}.log".format(hostname))

    crt.Session.SetStatusText("[POSTCHECK] Disabling paging...")
    try:
        screen.Send("terminal length 0\r")
        screen.WaitForString(prompt, 30)
    except Exception as e:
        raise Exception("Connection lost at start of postchecks: {}".format(e))

    with open(logfile, "w") as f:
        f.write("Hostname : {}\n".format(hostname))
        f.write("Collected: {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
        f.write("\n")

        for cmd in CHECK_COMMANDS:
            crt.Session.SetStatusText("[POSTCHECK] Running: {}".format(cmd))
            try:
                screen.Send(cmd + "\r")
                screen.WaitForString(cmd, 10)
                raw = screen.ReadString(prompt, 300)
            except Exception as e:
                f.write("=" * 70 + "\n")
                f.write("COMMAND : {}\n".format(cmd))
                f.write("=" * 70 + "\n")
                f.write("ERROR   : {}\n\n".format(str(e)))
                if "connect" in str(e).lower() or "lost" in str(e).lower():
                    f.write("(Stopping postcheck collection — connection lost)\n")
                    break
                continue

            output = _clean_output(raw, cmd, prompt)
            f.write("=" * 70 + "\n")
            f.write("COMMAND : {}\n".format(cmd))
            f.write("=" * 70 + "\n")
            f.write(output + "\n" if output else "(no output)\n")
            f.write("\n")
            time.sleep(0.5)

    crt.Session.SetStatusText("[POSTCHECK] Complete — {}".format(logfile))


# =============================================================================
# Phase 4 — Post-upgrade Validation & Report
# =============================================================================

def _run_check(cmd, prompt, expected_list, timeout=60):
    """Send cmd, clean its output, and verify every string in expected_list
    is present. Returns (ok, missing_list, cleaned_output)."""
    try:
        raw = _read_cmd_output(cmd, prompt, timeout=timeout)
    except Exception as e:
        return False, ["Command failed: {}".format(e)], ""
    output = _clean_output(raw, cmd, prompt)
    missing = [item for item in expected_list if item not in output]
    return (len(missing) == 0), missing, output


def _write_device_report_html(path, hostname, status, results):
    """Write a styled HTML report for a single device's validation run."""
    banner_class = "banner-success" if status == "SUCCESS" else "banner-notdone"

    rows = []
    for label, cmd, ok, missing, output in results:
        pill_class = "pill-pass" if ok else "pill-fail"
        pill_text  = "PASS" if ok else "FAIL"
        missing_html = ("<div class=\"missing\">Missing: {}</div>".format(
                            _html_escape("; ".join(missing)))
                         if missing else "")
        rows.append("""        <tr>
            <td>{label}</td>
            <td><code>{cmd}</code></td>
            <td><span class="pill {pill_class}">{pill_text}</span>{missing}</td>
            <td><pre>{output}</pre></td>
        </tr>""".format(
            label=_html_escape(label),
            cmd=_html_escape(cmd),
            pill_class=pill_class,
            pill_text=pill_text,
            missing=missing_html,
            output=_html_escape(output) if output else "(no output)"
        ))

    html = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Upgrade Validation Report - {hostname}</title>
<style>{css}</style>
</head>
<body>
    <h1>Post-Upgrade Validation Report</h1>
    <div class="meta">Hostname: {hostname} &nbsp;|&nbsp; Collected: {collected}</div>
    <div class="banner {banner_class}">Overall Result: {status}</div>
    <table>
        <tr><th>Check</th><th>Command</th><th>Result</th><th>Output</th></tr>
{rows}
    </table>
</body>
</html>""".format(
        hostname=_html_escape(hostname),
        css=REPORT_CSS,
        collected=time.strftime("%Y-%m-%d %H:%M:%S"),
        banner_class=banner_class,
        status=status,
        rows="\n".join(rows)
    )

    with open(path, "w") as f:
        f.write(html)


def _write_summary_report_html():
    """Rebuild the cumulative HTML dashboard from the CSV so it always
    reflects the full run history across every device processed so far.
    Includes a device/run count summary, a live hostname search box, and
    quick status filter tabs (all computed from the CSV, client-side)."""
    rows_data = []
    if os.path.exists(REPORT_SUMMARY_FILE):
        with open(REPORT_SUMMARY_FILE, "r") as f:
            lines = f.read().splitlines()
        for line in lines[1:]:  # skip header row
            parts = line.split(",", 3)
            if len(parts) < 4:
                continue
            ts, host, status, detail = parts
            rows_data.append((ts, host, status, detail))

    total_runs = len(rows_data)
    unique_hosts = set(host for _ts, host, _status, _detail in rows_data)
    device_count = len(unique_hosts)
    statuses_present = sorted(set(status for _ts, _host, status, _detail in rows_data))

    def pill_class_for(status):
        if status == "SUCCESS":
            return "pill-pass"
        if status == "ERROR":
            return "pill-error"
        return "pill-fail"

    rows = []
    for ts, host, status, detail in rows_data:
        pill_class = pill_class_for(status)
        rows.append("""        <tr data-hostname="{host_lower}" data-status="{status_raw}">
            <td>{ts}</td>
            <td>{host}</td>
            <td><span class="pill {pill_class}">{status}</span></td>
            <td>{detail}</td>
        </tr>""".format(
            host_lower=_html_escape(host.strip().lower()),
            status_raw=_html_escape(status.strip()),
            ts=_html_escape(ts),
            host=_html_escape(host),
            pill_class=pill_class,
            status=_html_escape(status),
            detail=_html_escape(detail)
        ))

    tabs = ['<button class="tab-btn active" data-status="ALL" onclick="setDeviceTab(this)">All ({0})</button>'.format(total_runs)]
    for st in statuses_present:
        count = sum(1 for _ts, _h, s, _d in rows_data if s == st)
        tabs.append('<button class="tab-btn" data-status="{0}" onclick="setDeviceTab(this)">{1} ({2})</button>'.format(
            _html_escape(st.strip()), _html_escape(st), count))

    html = """<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Upgrade Validation Summary</title>
<style>{css}</style>
</head>
<body>
    <h1>Upgrade Validation - All Devices</h1>
    <div class="meta">Last updated: {updated}</div>
    <div class="controls">
        <input type="text" id="deviceSearch" class="search-box" placeholder="Search hostname..." onkeyup="filterDevices()">
        <div class="stat">Devices: <b>{device_count}</b></div>
        <div class="stat">Runs: <b>{total_runs}</b></div>
        <div class="stat">Showing: <b id="visibleCount">{total_runs}</b></div>
    </div>
    <div class="tabs">{tabs}</div>
    <table id="deviceTable">
        <thead><tr><th>Timestamp</th><th>Hostname</th><th>Status</th><th>Details</th></tr></thead>
        <tbody>
{rows}
        </tbody>
    </table>
    <div class="no-results">No devices match your search.</div>
    <script>{script}</script>
</body>
</html>""".format(
        css=REPORT_CSS,
        updated=time.strftime("%Y-%m-%d %H:%M:%S"),
        device_count=device_count,
        total_runs=total_runs,
        tabs="\n        ".join(tabs),
        rows="\n".join(rows) if rows else "        <tr><td colspan=\"4\">No runs recorded yet.</td></tr>",
        script=SEARCH_JS
    )

    with open(REPORT_SUMMARY_HTML, "w") as f:
        f.write(html)


def _fix_boot_variable(prompt):
    """Reconfigure the boot variable to flash:packages.conf when 'show boot'
    doesn't already report it as the boot variable on next reload."""
    config_prompt = prompt.replace("#", "(config)#")
    crt.Session.SetStatusText("[REPORT] Boot variable not set correctly — fixing...")
    _send_and_wait("config t", config_prompt)
    _send_and_wait("no boot system", config_prompt)
    _send_and_wait("boot system flash:packages.conf", config_prompt)
    _send_and_wait("exit", prompt)
    _send_and_wait("wr mem", prompt)


def run_validation_report(screen, hostname, prompt):
    """Run the three post-upgrade verification commands, compare their
    output against the expected content, and write:
      - a per-device styled HTML report
      - a cumulative CSV (machine-readable backing store)
      - a cumulative styled HTML dashboard rebuilt from that CSV
    """
    _ensure_dir(REPORT_LOGDIR)
    detail_file = os.path.join(REPORT_LOGDIR, "{}.html".format(hostname))

    checks = [
        ("Boot variable",        "show boot",                                     EXPECTED_BOOT_LINES),
        ("Package build info",   "more flash:packages.conf | in pkginfo: Build",  EXPECTED_BUILD_LINES),
        ("Installed packages",   "dir flash: | in 17.15.06.SPA.pkg",              EXPECTED_PACKAGES),
    ]

    results = []
    for label, cmd, expected in checks:
        crt.Session.SetStatusText("[REPORT] Checking: {}".format(label))
        ok, missing, output = _run_check(cmd, prompt, expected)

        if label == "Boot variable" and not ok:
            try:
                _fix_boot_variable(prompt)
            except Exception as e:
                missing = missing + ["Remediation failed: {}".format(e)]
            else:
                # Re-check after applying the fix
                ok, missing, output = _run_check(cmd, prompt, expected)

        results.append((label, cmd, ok, missing, output))

    overall_ok = all(ok for _label, _cmd, ok, _missing, _out in results)
    status = "SUCCESS" if overall_ok else "NOT DONE"

    # Per-device styled HTML report
    _write_device_report_html(detail_file, hostname, status, results)

    # Shared cumulative CSV — one row per device per run
    write_header = not os.path.exists(REPORT_SUMMARY_FILE)
    with open(REPORT_SUMMARY_FILE, "a") as f:
        if write_header:
            f.write("Timestamp,Hostname,Status,Details\n")
        detail_bits = [
            "{}: missing {}".format(label, "; ".join(missing))
            for label, _cmd, ok, missing, _out in results if not ok
        ]
        detail_text = " | ".join(detail_bits) if detail_bits else "All checks passed"
        detail_text = detail_text.replace(",", ";").replace("\n", " ")
        f.write("{},{},{},{}\n".format(
            time.strftime("%Y-%m-%d %H:%M:%S"), hostname, status, detail_text))

    # Rebuild the cumulative HTML dashboard from the CSV
    _write_summary_report_html()

    crt.Session.SetStatusText(
        "[REPORT] {} — {} (details: {})".format(hostname, status, detail_file))
    return status


# =============================================================================
# Entry point
# =============================================================================

def main():
    tab = crt.GetScriptTab()

    if not tab.Session.Connected:
        crt.Dialog.MessageBox("Session is not connected. Aborting.")
        return

    screen = tab.Screen
    screen.Synchronous = True
    screen.IgnoreEscape = True

    try:
        hostname_raw, PROMPT = _detect_hostname_and_prompt()
    except Exception as e:
        crt.Dialog.MessageBox("Failed to detect hostname:\n{}".format(e))
        return

    hostname_safe = _sanitise_hostname(hostname_raw)

    # Phase 1 — Prechecks
    try:
        run_prechecks(screen, hostname_safe, PROMPT, PRECHECK_LOGDIR)
    except Exception as e:
        crt.Session.SetStatusText("[PRECHECK] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Prechecks failed:\n{}\n\nScript aborted.".format(e))
        return

    # Re-detect prompt
    PROMPT = _get_prompt_from_screen(screen) or PROMPT

    # Phase 2 — Install Mode
    implement_log = _start_implement_logging(hostname_safe)
    crt.Session.SetStatusText("[INSTALL] Logging to {}".format(implement_log))
    try:
        run_install_mode(PROMPT)
    except Exception as e:
        crt.Session.SetStatusText("[INSTALL] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Install Mode failed:\n{}\n\nScript aborted.".format(e))
        return
    finally:
        _stop_implement_logging()

    # Re-detect prompt
    PROMPT = _get_prompt_from_screen(screen) or PROMPT

    # Phase 3 — Postchecks
    try:
        run_postchecks(screen, hostname_safe, PROMPT, POSTCHECK_LOGDIR)
    except Exception as e:
        crt.Session.SetStatusText("[POSTCHECK] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Postchecks failed:\n{}\n\nScript aborted.".format(e))
        return

    # Phase 4 — Post-upgrade validation & report
    try:
        run_validation_report(screen, hostname_safe, PROMPT)
    except Exception as e:
        crt.Session.SetStatusText("[REPORT] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Validation/report generation failed:\n{}\n\nScript aborted.".format(e))
        return

    crt.Session.SetStatusText("All phases complete.")


main()
