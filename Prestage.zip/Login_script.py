# $language = "python"
# $interface = "1.0"

import os
import time

USERNAME = "E145000"
COMBINE_SEPARATOR = ","
CONNECT_DELAY_MS = 200
TRY_INTERACTIVE_FALLBACK = True

script_dir = os.path.dirname(crt.ScriptFullName)
nodes_file = os.path.join(script_dir, "nodes.txt")


# ----------------------------
# Utility Functions
# ----------------------------

def status(msg):
    try:
        crt.Session.SetStatusText(msg)
    except:
        pass


def qq(s):
    return f'"{s}"'


def split_combined(combined):
    if COMBINE_SEPARATOR not in combined:
        return None, None

    parts = combined.split(COMBINE_SEPARATOR, 1)
    pass_part = parts[0].strip()
    id_part = parts[1].strip()

    if pass_part and id_part:
        return pass_part, id_part
    return None, None


def load_hosts(file_path):
    hosts = []

    if not os.path.exists(file_path):
        return None

    with open(file_path, "r") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                hosts.append(line)

    return hosts if hosts else None


# ----------------------------
# Connection Functions
# ----------------------------

def connect_direct(host, user, combined):
    try:
        cmd = f'/SSH2 /ACCEPTHOSTKEYS /AUTH password /L {qq(user)} /PASSWORD {qq(combined)} {host}'
        tab = crt.Session.ConnectInTab(cmd)

        if tab:
            tab.Caption = host
            return True
    except:
        pass

    return False


def connect_interactive(host, user, combined):
    try:
        cmd = f'/SSH2 /ACCEPTHOSTKEYS /AUTH keyboard-interactive,password /L {qq(user)} {host}'
        tab = crt.Session.ConnectInTab(cmd)

        if not tab:
            return

        tab.Caption = host
        tab.Screen.Synchronous = True

        if tab.Screen.WaitForString("assword:", 15):
            tab.Screen.Send(combined + "\r")

    except:
        pass


# ----------------------------
# Main Logic
# ----------------------------

def main():

    hosts = load_hosts(nodes_file)

    if not hosts:
        status(f"nodes.txt not found or empty: {nodes_file}")
        return

    last_password = ""

    for host in hosts:

        host = host.strip()
        if not host:
            continue

        proceed = True
        combined = ""

        # First device → ask password + PingID
        if last_password == "":
            user_input = crt.Dialog.Prompt(
                f"[{host}] Enter password{COMBINE_SEPARATOR}PingID (no spaces):",
                "SecureCRT Login",
                "",
                True
            )

            user_input = user_input.strip()

            if not user_input:
                proceed = False
                status(f"Skipped {host} (no input)")
            else:
                p1, p2 = split_combined(user_input)
                if not p1:
                    proceed = False
                    status(f"Invalid input. Need password{COMBINE_SEPARATOR}PingID")
                else:
                    last_password = p1
                    combined = f"{p1}{COMBINE_SEPARATOR}{p2}"

        # Next devices → only PingID
        else:
            prompt_msg = (
                f"[{host}] Enter PingID only (password saved).\n"
                f"TIP: To change password, enter full 'password{COMBINE_SEPARATOR}PingID'."
            )

            pin = crt.Dialog.Prompt(prompt_msg, "SecureCRT Login", "", True)
            pin = pin.strip()

            if not pin:
                proceed = False
                status(f"Skipped {host} (no PingID)")
            else:
                # If full input provided again
                if COMBINE_SEPARATOR in pin:
                    p3, p4 = split_combined(pin)
                    if not p3:
                        proceed = False
                        status("Invalid full input")
                    else:
                        last_password = p3
                        combined = f"{p3}{COMBINE_SEPARATOR}{p4}"
                else:
                    combined = f"{last_password}{COMBINE_SEPARATOR}{pin}"

        # Connect
        if proceed:
            success = connect_direct(host, USERNAME, combined)

            if not success and TRY_INTERACTIVE_FALLBACK:
                connect_interactive(host, USERNAME, combined)

        crt.Sleep(CONNECT_DELAY_MS)

    status("All done. Tabs remain open.")


# Run
main()