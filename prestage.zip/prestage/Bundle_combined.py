# $language = "Python"
# $interface = "1.0"

# =============================================================================
# Combined Script: Prechecks → Install Mode Upgrade → Postchecks
# Runs all three phases sequentially without any manual prompts.
# Connection-loss protected: every screen read is wrapped in try/except so a
# dropped session raises a clean error instead of crashing with ScriptError.
# =============================================================================

import os
import re
import time

# ----------------------------
# User-editable constants
# ----------------------------
EXPECTED_MD5      = "1840f673c3f798195408c1ca8e78c904"
IMAGE_BIN         = "cat9k_iosxe.17.15.05.SPA.bin"
FTP_URL           = "http://0.0.0.0:1515/C9300/" + IMAGE_BIN

ECHO_SUPPRESS_SEC = 1.0

PRECHECK_LOGDIR   = r"C:\Logs\Prechecks"
POSTCHECK_LOGDIR  = r"C:\Logs\postcheck"

CHECK_COMMANDS = [
    "show clock",
    "show version",
    "show ip interface brief",
    "show interfaces status",
    "show interfaces trunk",
    "show module",
    "show vlan brief",
    "show post",
    "show boot",
    "show power inline",
    "show spanning-tree detail",
    "dir",
    "show mac address-table",
    "show flash:",
    "show ip arp",
    "show switch",
    "show env all",
]


# =============================================================================
# Connection guard
# =============================================================================

def _check_connected(tab):
    """Raise a clean exception if the session has dropped."""
    if not tab.Session.Connected:
        raise Exception("Connection lost — session is no longer connected.")


# =============================================================================
# Shared helpers
# =============================================================================

def _detect_hostname_and_prompt():
    try:
        crt.Screen.Send("\r")
        time.sleep(0.2)
        crt.Screen.Send("term len 0\r")
        time.sleep(0.3)
        crt.Screen.Send("show version | include uptime\r")
        time.sleep(0.5)
        row  = crt.Screen.CurrentRow
        col  = crt.Screen.CurrentColumn
        text = crt.Screen.Get(max(1, row - 20), 1, row, col)
        hostname = None
        for line in text.splitlines():
            m = re.search(r"^(\S+)\s+uptime is", line.strip())
            if m:
                hostname = m.group(1)
                break
        if not hostname:
            crt.Screen.Send("\r")
            time.sleep(0.2)
            line = crt.Screen.Get(
                crt.Screen.CurrentRow, 1,
                crt.Screen.CurrentRow, crt.Screen.CurrentColumn
            ).strip()
            m = re.match(r"^(\S+)[>#]$", line)
            if m:
                hostname = m.group(1)
        if not hostname:
            hostname = "UNKNOWN"
        return hostname, hostname + "#"
    except Exception as e:
        raise Exception("Failed to detect hostname: {}".format(e))


def _get_prompt_from_screen(screen):
    try:
        screen.Send("\r")
        time.sleep(1)
        row = screen.CurrentRow
        return screen.Get(row, 1, row, screen.CurrentColumn).strip()
    except Exception:
        return ""


def _sanitise_hostname(raw):
    for ch in ("/", "\\", ":", " "):
        raw = raw.replace(ch, "_")
    return raw


def _ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def _clean_output(raw, cmd, prompt):
    """Strip ANSI escapes, control chars, echoed command, and bare prompt lines."""
    ansi_escape = re.compile(r'\x1b\[[0-9;]*[A-Za-z]')
    raw = ansi_escape.sub('', raw)
    raw = raw.replace('\r', '').replace('\x08', '').replace('\x07', '')

    cleaned = []
    for line in raw.splitlines():
        s = line.rstrip()
        if s.strip() == cmd.strip():
            continue
        if re.match(r'^\S+[>#]\s*$', s.strip()):
            continue
        prompt_bare = prompt.rstrip()
        if s.strip().startswith(prompt_bare):
            if not s.strip()[len(prompt_bare):].strip():
                continue
        cleaned.append(s)

    while cleaned and not cleaned[0].strip():
        cleaned.pop(0)
    while cleaned and not cleaned[-1].strip():
        cleaned.pop()

    return '\n'.join(cleaned)


# =============================================================================
# Install Mode screen helpers — all wrapped for connection safety
# =============================================================================

def _wait_for_prompt(prompt, timeout=120):
    try:
        crt.Screen.WaitForString(prompt, timeout)
    except Exception as e:
        raise Exception("Connection lost while waiting for prompt: {}".format(e))


def _send_and_wait(cmd, prompt, timeout=120, pre_delay=0.1):
    try:
        crt.Screen.Send(cmd + "\r")
        if pre_delay:
            time.sleep(pre_delay)
        _wait_for_prompt(prompt, timeout)
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _send_long_and_wait(cmd, prompt, timeout=3600):
    try:
        crt.Screen.Send(cmd + "\r")
        _wait_for_prompt(prompt, timeout)
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _read_cmd_output(cmd, prompt, timeout=3600):
    try:
        crt.Screen.Send(cmd + "\r")
        data = crt.Screen.ReadString(prompt, timeout)
        return data
    except Exception as e:
        raise Exception("Connection lost reading output of '{}': {}".format(cmd, e))


def _send_with_confirm(cmd, prompt, timeout=600):
    try:
        crt.Screen.Send(cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["[confirm]", "Destination filename", "dest filename", "overwrite", prompt],
                timeout
            )
            if idx in [1, 2, 3, 4]:
                crt.Screen.Send("\r")
            elif idx == 5:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


def _copy_with_enter_when_prompted(copy_cmd, prompt, timeout=7200):
    try:
        crt.Screen.Send(copy_cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["Destination filename", "Address or name of remote host", "Password:", prompt],
                timeout
            )
            if idx in [1, 2, 3]:
                crt.Screen.Send("\r")
            elif idx == 4:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during copy: {}".format(e))


def _copy_running_to_flash(dest_filename, prompt, timeout=900):
    try:
        crt.Screen.Send("copy running-config flash:{}\r".format(dest_filename))
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["Destination filename", "[confirm]", "copied", prompt],
                timeout
            )
            if idx in [1, 2]:
                crt.Screen.Send("\r")
            elif idx == 4:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during config backup: {}".format(e))


def _send_yes_if_prompted(cmd, prompt, timeout=3600):
    try:
        crt.Screen.Send(cmd + "\r")
        start = time.time()
        while True:
            idx = crt.Screen.WaitForStrings(
                ["[y/n]", "(y/n)", "[confirm]", prompt],
                timeout
            )
            if idx in [1, 2]:
                crt.Screen.Send("y\r")
            elif idx == 3:
                crt.Screen.Send("\r")
            elif idx == 4:
                if time.time() - start < ECHO_SUPPRESS_SEC:
                    continue
                break
    except Exception as e:
        raise Exception("Connection lost during '{}': {}".format(cmd, e))


# =============================================================================
# Phase 1 — Prechecks
# =============================================================================

def run_prechecks(screen, hostname, prompt, logdir):
    _ensure_dir(logdir)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    logfile   = os.path.join(logdir, "{}_{}.txt".format(hostname, timestamp))

    crt.Session.SetStatusText("[PRECHECK] Disabling paging...")
    try:
        screen.Send("terminal length 0\r")
        screen.WaitForString(prompt, 30)
    except Exception as e:
        raise Exception("Connection lost at start of prechecks: {}".format(e))

    with open(logfile, "w") as f:
        f.write("Hostname : {}\n".format(hostname))
        f.write("Collected: {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
        f.write("\n")

        for cmd in CHECK_COMMANDS:
            crt.Session.SetStatusText("[PRECHECK] Running: {}".format(cmd))
            try:
                screen.Send(cmd + "\r")
                screen.WaitForString(cmd, 10)
                raw = screen.ReadString(prompt, 300)
            except Exception as e:
                f.write("=" * 70 + "\n")
                f.write("COMMAND : {}\n".format(cmd))
                f.write("=" * 70 + "\n")
                f.write("ERROR   : {}\n\n".format(str(e)))
                # If it looks like a connection loss, stop collecting
                if "connect" in str(e).lower() or "lost" in str(e).lower():
                    f.write("(Stopping precheck collection — connection lost)\n")
                    break
                continue

            output = _clean_output(raw, cmd, prompt)
            f.write("=" * 70 + "\n")
            f.write("COMMAND : {}\n".format(cmd))
            f.write("=" * 70 + "\n")
            f.write(output + "\n" if output else "(no output)\n")
            f.write("\n")
            time.sleep(0.5)

    crt.Session.SetStatusText("[PRECHECK] Complete — {}".format(logfile))


# =============================================================================
# Phase 2 — Bundle Mode Upgrade
# =============================================================================

def run_bundle_mode(prompt):
    # Backup config
    crt.Session.SetStatusText("[BUNDLE] Backing up running config...")
    _copy_running_to_flash("config_{}".format(time.strftime("%d_%m_%Y")), prompt)

    # Basic checks
    for cmd in ("term len 0", "show version", "show clock",
                "show platform", "show inventory", "dir flash:"):
        crt.Session.SetStatusText("[BUNDLE] {}".format(cmd))
        _send_and_wait(cmd, prompt)

    # Ping check
    crt.Session.SetStatusText("[BUNDLE] Ping check to FTP server...")
    ping_out = _read_cmd_output("ping 10.233.30.222", prompt, timeout=120)
    if ("Success rate is 0 percent" in ping_out
            or "0/5" in ping_out
            or "Unreachable" in ping_out):
        crt.Dialog.MessageBox("Ping to FTP server FAILED. Stopping script.")
        raise Exception("Ping failed — aborting.")

    _send_and_wait("show install active", prompt)

    # Clean flash
    crt.Session.SetStatusText("[BUNDLE] Cleaning flash...")
    _send_yes_if_prompted("request platform software package clean", prompt, timeout=3600)

    _send_and_wait("dir flash:*.bin", prompt)
    _send_and_wait("dir flash: | inc free", prompt)

    # Copy image
    crt.Session.SetStatusText("[BUNDLE] Copying image from FTP (may take a while)...")
    _copy_with_enter_when_prompted("copy {} flash:".format(FTP_URL), prompt, timeout=7200)
    _send_and_wait("dir flash:*.bin", prompt)

    # Verify integrity
    crt.Session.SetStatusText("[BUNDLE] Verifying image integrity...")
    _send_long_and_wait("verify flash:{}".format(IMAGE_BIN), prompt, timeout=3600)

    # MD5 check
    crt.Session.SetStatusText("[BUNDLE] Verifying MD5 hash...")
    md5_out      = _read_cmd_output("verify /md5 flash:{}".format(IMAGE_BIN), prompt, timeout=7200)
    md5_match    = re.search(r"=\s*([A-Fa-f0-9]{32})", md5_out)
    computed_md5 = md5_match.group(1).lower() if md5_match else "NOT_FOUND"

    if computed_md5 != EXPECTED_MD5.lower():
        crt.Dialog.MessageBox(
            "MD5 MISMATCH!\nExpected: {}\nGot: {}\nStopping script.".format(
                EXPECTED_MD5, computed_md5))
        raise Exception("MD5 mismatch — aborting.")

    # Configure bundle boot
    crt.Session.SetStatusText("[BUNDLE] Configuring boot variable...")

    config_prompt = prompt.replace("#", "(config)#")

    _send_and_wait("config t", config_prompt)
    _send_and_wait("no boot system", config_prompt)
    _send_and_wait("boot system flash:{}".format(IMAGE_BIN), config_prompt)
    _send_and_wait("end", prompt)
    _send_and_wait("wr mem", prompt)
    _send_and_wait("show boot system", prompt)

# =============================================================================
# Phase 3 — Postchecks
# =============================================================================

def run_postchecks(screen, hostname, prompt, logdir):
    _ensure_dir(logdir)
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    logfile   = os.path.join(logdir, "{}_{}.txt".format(hostname, timestamp))

    crt.Session.SetStatusText("[POSTCHECK] Disabling paging...")
    try:
        screen.Send("terminal length 0\r")
        screen.WaitForString(prompt, 30)
    except Exception as e:
        raise Exception("Connection lost at start of postchecks: {}".format(e))

    with open(logfile, "w") as f:
        f.write("Hostname : {}\n".format(hostname))
        f.write("Collected: {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
        f.write("\n")

        for cmd in CHECK_COMMANDS:
            crt.Session.SetStatusText("[POSTCHECK] Running: {}".format(cmd))
            try:
                screen.Send(cmd + "\r")
                screen.WaitForString(cmd, 10)
                raw = screen.ReadString(prompt, 300)
            except Exception as e:
                f.write("=" * 70 + "\n")
                f.write("COMMAND : {}\n".format(cmd))
                f.write("=" * 70 + "\n")
                f.write("ERROR   : {}\n\n".format(str(e)))
                if "connect" in str(e).lower() or "lost" in str(e).lower():
                    f.write("(Stopping postcheck collection — connection lost)\n")
                    break
                continue

            output = _clean_output(raw, cmd, prompt)
            f.write("=" * 70 + "\n")
            f.write("COMMAND : {}\n".format(cmd))
            f.write("=" * 70 + "\n")
            f.write(output + "\n" if output else "(no output)\n")
            f.write("\n")
            time.sleep(0.5)

    crt.Session.SetStatusText("All phases complete.")


# =============================================================================
# Entry point
# =============================================================================

def main():
    tab = crt.GetScriptTab()

    if not tab.Session.Connected:
        crt.Dialog.MessageBox("Session is not connected. Aborting.")
        return

    screen = tab.Screen
    screen.Synchronous = True
    screen.IgnoreEscape = True

    try:
        hostname_raw, PROMPT = _detect_hostname_and_prompt()
    except Exception as e:
        crt.Dialog.MessageBox("Failed to detect hostname:\n{}".format(e))
        return

    hostname_safe = _sanitise_hostname(hostname_raw)

    # Phase 1 — Prechecks
    try:
        run_prechecks(screen, hostname_safe, PROMPT, PRECHECK_LOGDIR)
    except Exception as e:
        crt.Session.SetStatusText("[PRECHECK] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Prechecks failed:\n{}\n\nScript aborted.".format(e))
        return

    # Re-detect prompt
    PROMPT = _get_prompt_from_screen(screen) or PROMPT

    # Phase 2 — Install Mode
    try:
        run_bundle_mode(PROMPT)
    except Exception as e:
        crt.Session.SetStatusText("[INSTALL] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Bundle Mode failed:\n{}\n\nScript aborted.".format(e))
        return

    # Re-detect prompt
    PROMPT = _get_prompt_from_screen(screen) or PROMPT

    # Phase 3 — Postchecks
    try:
        run_postchecks(screen, hostname_safe, PROMPT, POSTCHECK_LOGDIR)
    except Exception as e:
        crt.Session.SetStatusText("[POSTCHECK] FAILED: {}".format(e))
        crt.Dialog.MessageBox("Postchecks failed:\n{}\n\nScript aborted.".format(e))
        return

    crt.Session.SetStatusText("All phases complete.")


main()
