# $language = "Python"
# $interface = "1.0"

import os
import time

# ======================================================
# CONFIGURATION
# ======================================================

SCRIPT_PATH = r"C:\scripts"

# ======================================================
# HELPER FUNCTIONS
# ======================================================

def send(cmd):
    crt.Screen.Send(cmd + "\r")


def get_prompt():
    send("")
    time.sleep(1)

    row = crt.Screen.CurrentRow
    line = crt.Screen.Get(row, 1, row, crt.Screen.CurrentColumn).strip()

    hostname = line.replace("#", "").replace(">", "").strip()

    if "#" in line:
        prompt = hostname + "#"
    else:
        prompt = hostname + ">"

    return hostname, prompt


def read_output(cmd, prompt, timeout=30):
    send(cmd)
    return crt.Screen.ReadString(prompt, timeout)


# ======================================================
# DETECT INSTALL/BUNDLE MODE
# ======================================================

def detect_mode(prompt):

    output = read_output(
        "show version | include System image file",
        prompt
    ).lower()

    if ".conf" in output:
        return "INSTALL"

    elif ".bin" in output:
        return "BUNDLE"

    else:
        return "UNKNOWN"


# ======================================================
# EXECUTE CHILD SCRIPT
# ======================================================

def run_script(script_name):

    full_path = os.path.join(SCRIPT_PATH, script_name)

    if not os.path.exists(full_path):
        crt.Dialog.MessageBox(
            "Cannot find script:\n\n{}".format(full_path)
        )
        return

    try:
        with open(full_path, "r") as f:
            code = compile(f.read(), full_path, "exec")

        namespace = globals().copy()
        namespace["crt"] = crt

        exec(code, namespace)

    except Exception as e:
        crt.Dialog.MessageBox(
            "Error executing {}\n\n{}".format(script_name, str(e))
        )


# ======================================================
# MAIN
# ======================================================

def main():

    hostname, prompt = get_prompt()

    crt.Session.SetStatusText("Detecting boot mode...")

    mode = detect_mode(prompt)

    crt.Session.SetStatusText("Detected: " + mode)

    if mode == "INSTALL":
        run_script("Install_Combined.py")

    elif mode == "BUNDLE":
        run_script("Bundle_combined.py")

    else:
        crt.Dialog.MessageBox(
            "Unable to detect Install/Bundle mode."
        )


main()